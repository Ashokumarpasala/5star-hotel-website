
const hamburger = document.querySelector('.header-hamburger-icon');
const standardRoomSelector = document.querySelector('#standard-room')
const executiveRoomSelector = document.querySelector('#executive-room')
const kingRoomSelector = document.querySelector('#king-room')

